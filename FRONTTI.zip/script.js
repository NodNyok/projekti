// Kirjojen lista, jokaisella kirjalla on otsikko ja siihen liittyvä kuvatiedosto
const books = [
  { title: "The Hobbit", image: "kirjatkuvat/hobitti.jpg" },
  { title: "The Picture of Dorian Gray", image: "kirjatkuvat/pictureofdoriangraythe.jpg" },
  { title: "The Stranger", image: "kirjatkuvat/thestranger.jpg" },
  { title: "Thus Spoke Zarathustra", image: "kirjatkuvat/thusspokezarathustra.jpg" },
  { title: "The Unknown Soldier", image: "kirjatkuvat/tuntematonsotilas.jpg" },
  { title: "The Idiot", image: "kirjatkuvat/theidiot.jpg" }
];

let currentIndex = 0; // Pitää kirjaa siitä, mikä kirja on parhaillaan näytössä

// Näyttää kirjan annetulla indeksillä
function showBook(index) {
  if (index >= books.length) {
    // Jos päästään listan loppuun, aloitetaan alusta
    currentIndex = 0;
    index = 0;
  }

  const book = books[index];
  const bookTitle = document.getElementById("book-title");
  const bookImage = document.getElementById("book-image");

  // Päivitetään otsikko ja kuva näkyviin
  bookTitle.textContent = book.title;
  bookImage.src = book.image;
  bookImage.style.display = "block";

  // Poistetaan mahdolliset aiemmat animaatioluokat
  bookImage.classList.remove("animate-left", "animate-right");
}

// Lisää animaation ja näyttää seuraavan kirjan
function animateAndShowNext(direction) {
  const bookImage = document.getElementById("book-image");

  // Poistetaan mahdolliset aiemmat animaatiot
  bookImage.classList.remove("animate-left", "animate-right");

  // Pakotetaan reflow, jotta animaatio varmasti toimii (resetoi animaation)
  void bookImage.offsetWidth;

  // Lisätään uusi animaatioluokka suunnan mukaan
  bookImage.classList.add(direction === "right" ? "animate-right" : "animate-left");

  // Odotetaan animaation loppua ja sitten näytetään seuraava kirja
  setTimeout(() => {
    currentIndex = (currentIndex + 1) % books.length; // Kierrätetään indeksin arvoa
    showBook(currentIndex);
  }, 500); // Odotetaan 500 ms, joka vastaa animaation kestoa
}

// "Tykkää"-painikkeen (kirjan) animaatio ja toiminta
document.querySelector(".like-btn").addEventListener("click", () => {
  const bookIcon = document.getElementById("book-icon");

  // Tallennetaan alkuperäinen kuva, jos ei vielä ole tallennettu
  if (!bookIcon.dataset.originalSrc) {
    bookIcon.dataset.originalSrc = bookIcon.src;
  }

  // Asetetaan animaatiokuva
  bookIcon.src = "kirja.gif";

  // Odotetaan animaatio loppuun ja palautetaan alkuperäinen kuva
  setTimeout(() => {
    bookIcon.src = bookIcon.dataset.originalSrc;
    animateAndShowNext("right"); // Näytetään seuraava kirja oikealle suunnaten
  }, 1000); // Animaation kesto
});

// "Roskakori"-painikkeen animaatio ja toiminta
document.querySelector(".trash-btn").addEventListener("click", () => {
  const trashIcon = document.getElementById("trash-icon");

  // Tallennetaan alkuperäinen kuva, jos ei vielä ole tallennettu
  if (!trashIcon.dataset.originalSrc) {
    trashIcon.dataset.originalSrc = trashIcon.src;
  }

  // Asetetaan animaatiokuva
  trashIcon.src = "roskakori.gif";

  // Odotetaan animaatio loppuun ja palautetaan alkuperäinen kuva
  setTimeout(() => {
    trashIcon.src = trashIcon.dataset.originalSrc;
    animateAndShowNext("left"); // Näytetään seuraava kirja vasemmalle suunnaten
  }, 1000); // Animaation kesto
});

// Alussa näytetään ensimmäinen kirja
showBook(currentIndex);
