const books = [
  { title: "The Hobbit", image: "kirjatkuvat/hobitti.jpg" },
  { title: "The Picture of Dorian Gray", image: "kirjatkuvat/pictureofdoriangraythe.jpg" },
  { title: "The Stranger", image: "kirjatkuvat/thestranger.jpg" },
  { title: "Thus Spoke Zarathustra", image: "kirjatkuvat/thusspokezarathustra.jpg" },
  { title: "The Unknown Soldier", image: "kirjatkuvat/tuntematonsotilas.jpg" }
];

let currentIndex = 0;

function showBook(index) {
  if (index >= books.length) {
    // Jos kirjat loppuivat, palataan listan alkuun
    currentIndex = 0;
    index = 0;
  }

  const book = books[index];
  const bookTitle = document.getElementById("book-title");
  const bookImage = document.getElementById("book-image");

  bookTitle.textContent = book.title;
  bookImage.src = book.image;
  bookImage.style.display = "block";
  bookImage.classList.remove("animate-left", "animate-right");
}

function animateAndShowNext(direction) {
  const bookImage = document.getElementById("book-image");

  // Poista vanhat animaatiot
  bookImage.classList.remove("animate-left", "animate-right");

  // Pakota reflow (uudelleenlataus jotta animaatio toimii aina)
  void bookImage.offsetWidth;

  // Lisää uusi animaatio
  bookImage.classList.add(direction === "right" ? "animate-right" : "animate-left");

  // Odota animaation loppua ennen seuraavaa kirjaa
  setTimeout(() => {
    currentIndex = (currentIndex + 1) % books.length; // Käytä modulo-operaatiota kierrättääksesi listan
    showBook(currentIndex);
  }, 500); // vastaava aika kuin animaatiolla
}

// Kirja-painikkeen animaatio (nyt samanlainen kuin roskakorilla)
document.querySelector(".like-btn").addEventListener("click", () => {
  const bookIcon = document.getElementById("book-icon");
  
  // Alkuperäinen kuva tallennetaan jos sitä ei ole jo tallennettu
  if (!bookIcon.dataset.originalSrc) {
    bookIcon.dataset.originalSrc = bookIcon.src;
  }
  
  bookIcon.src = "kirja.gif"; // Aseta animaatio
  setTimeout(() => {
    bookIcon.src = bookIcon.dataset.originalSrc; // Palauta alkuperäinen kuva
    animateAndShowNext("right");
  }, 1000); // Animaation kesto
});

// Roskakori-painikkeen animaatio
document.querySelector(".trash-btn").addEventListener("click", () => {
  const trashIcon = document.getElementById("trash-icon");
  
  // Alkuperäinen kuva tallennetaan jos sitä ei ole jo tallennettu
  if (!trashIcon.dataset.originalSrc) {
    trashIcon.dataset.originalSrc = trashIcon.src;
  }
  
  trashIcon.src = "roskakori.gif"; // Aseta animaatio
  setTimeout(() => {
    trashIcon.src = trashIcon.dataset.originalSrc; // Palauta alkuperäinen kuva
    animateAndShowNext("left");
  }, 1000); // Animaation kesto
});

// Alussa näytä ensimmäinen kirja
showBook(currentIndex);